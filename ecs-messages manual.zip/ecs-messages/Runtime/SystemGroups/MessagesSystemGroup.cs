using Unity.Entities;

namespace CortexDeveloper.ECSMessages.SystemGroups
{
    [DisableAutoCreation]
    public partial class MessagesSystemGroup : ComponentSystemGroup { }
}