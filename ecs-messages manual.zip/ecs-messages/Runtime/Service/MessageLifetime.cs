﻿namespace CortexDeveloper.ECSMessages.Service
{
    public enum MessageLifetime
    {
        Unlimited,
        OneFrame,
	    TimeInterval,
	    Manual
    }
}