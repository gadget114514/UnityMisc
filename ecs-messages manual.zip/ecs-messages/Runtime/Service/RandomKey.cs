namespace CortexDeveloper.ECSMessages.Service
{
    internal abstract class RandomKey { }
}