using Unity.Entities;

namespace CortexDeveloper.ECSMessages.Components.Meta
{
    public struct MessageLifetimeOneFrameTag : IComponentData { }
}