using Unity.Entities;

namespace CortexDeveloper.ECSMessages.Components.Meta
{
    public struct MessageTag : IComponentData { }
}