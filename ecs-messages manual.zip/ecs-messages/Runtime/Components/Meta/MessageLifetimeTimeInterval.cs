﻿using Unity.Entities;

namespace CortexDeveloper.ECSMessages.Components.Meta
{
    public struct MessageLifetimeTimeInterval : IComponentData
    {
        public float LifetimeLeft;
    }
    
	public struct MessageLifetimeManual : IComponentData
	{
		public bool LifetimeLeft;
	}
}