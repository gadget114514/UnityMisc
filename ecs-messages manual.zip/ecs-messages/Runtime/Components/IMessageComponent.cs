﻿namespace CortexDeveloper.ECSMessages.Components
{
    public interface IMessageComponent { }
}