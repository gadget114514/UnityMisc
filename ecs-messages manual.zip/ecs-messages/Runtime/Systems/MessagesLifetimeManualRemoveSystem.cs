﻿using CortexDeveloper.ECSMessages.Components.Meta;
using Unity.Burst;
using Unity.Collections;
using Unity.Entities;

namespace CortexDeveloper.ECSMessages.Systems
{
	  [DisableAutoCreation]
    [BurstCompile]
	public partial struct MessagesLifetimeManualRemoveSystem : ISystem
    {
        [BurstCompile]
        public void OnUpdate(ref SystemState state)
        {
            EntityCommandBuffer ecb = new(Allocator.TempJob);

            new DestroyMessagesJob
            {
                ECB = ecb
            }.Schedule();
            
            state.Dependency.Complete();

            ecb.Playback(state.EntityManager);
            ecb.Dispose();
        }
    }
    
    [BurstCompile]
    internal partial struct DestroyMessagesJob : IJobEntity
    {
        public EntityCommandBuffer ECB;

	    public void Execute(Entity entity, in MessageTag messageTag, in MessageLifetimeManual cc)
        {
	        if (cc.LifetimeLeft == false)
                ECB.DestroyEntity(entity);
        }
    }
}