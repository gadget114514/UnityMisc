﻿using CortexDeveloper.ECSMessages.Components;
using Unity.Entities;

namespace Samples.UserInterfaceExample
{
    public struct PauseGameCommand : IComponentData, IMessageComponent { }
}