﻿using CortexDeveloper.ECSMessages.Service;
using Unity.Entities;
using UnityEngine;
using UnityEngine.UI;


namespace Samples.UserInterfaceExample
{
    [RequireComponent(typeof(Button))]
    public class StartGameButton : MonoBehaviour
    {
	    public Text MatchDurationInputField;
	    public Text EnemiesCountInputField;
	    
        private Button _button;
    
        private void Awake()
        {
            _button = GetComponent<Button>();
            _button.onClick.AddListener(StartGame);
        }

        private void OnDestroy()
        {
            _button.onClick.RemoveListener(StartGame);
        }

        private void StartGame()
	    {
		    //	    Debug.Log("start game");
		    
            EntityManager entityManager = World.DefaultGameObjectInjectionWorld.EntityManager;

            float.TryParse(MatchDurationInputField.text, out float duration);
            int.TryParse(EnemiesCountInputField.text, out int enemies);
            
		    Debug.Log("a=" + duration + " " + enemies);
		    
            MessageBroadcaster
                .PrepareMessage()
                .AliveForOneFrame()
                .PostImmediate(entityManager,
                    new StartGameCommand
                    {
                        Duration = duration,
                        Enemies = enemies,
                    });
        }
    }
}
