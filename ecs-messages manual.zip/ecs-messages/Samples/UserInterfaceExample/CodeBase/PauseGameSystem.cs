﻿using Unity.Entities;
using UnityEngine;

namespace Samples.UserInterfaceExample
{
  [DisableAutoCreation]
    public partial struct PauseGameSystem : ISystem
    {
        public void OnCreate(ref SystemState state)
        {
            state.RequireForUpdate<PauseGameCommand>();       
        }
        
        public void OnUpdate(ref SystemState state)
	    {
		    foreach (var a in SystemAPI.Query<RefRW<PauseGameCommand>>()) {
			    Debug.Log("Game paused");
		    }
        }
    }
}